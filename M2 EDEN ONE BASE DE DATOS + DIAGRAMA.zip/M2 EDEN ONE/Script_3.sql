
insert into usuario (username,password) values ("anthony","12345");
insert into usuario (username,password) values ("joao","1234567");


insert into aventura (name,descripcion) values ("El Bosque Maldito","Nuestro heroe, se embarca en la busqueda de la espada llamada La Ira de los Cielos");
insert into aventura (name,descripcion) values ("Un Pasado Inesperado","Su vida pasada y su vida actual se cruzan: ¡un chico con recuerdos de dos vidas se enfrenta a su destino!");
insert into aventura (name,descripcion) values ("En Busca de La Muerte","Un chico intentara salvar a su novia a manos de la muerte");
insert into aventura (name,descripcion) values ("No Mires Nada","No abras los ojos en este thriller de aventura en que no podras confiar en nadie o moriras");
insert into aventura (name,descripcion) values ("El Camino del Saber","Nuestro protagonista se embarcara en una aventura para conseguir la reliquia del saber");
insert into aventura (name,descripcion) values ("Eleccion Equivocada","Elije o muere solo elijiendo las opciones correctas sobreviviras");


insert into personajes (name,descripcion) values ("Akiro","Es un chico alto de pelo negro y ojos de azules");
insert into personajes (name,descripcion) values ("Manzo","Es un chico alto y timido con el pelo castaño y ojos de verdes");
insert into personajes (name,descripcion) values ("Kazuya","Es un chico pequeño al cual no le gusta respetar las normas");

/*Camino Principal*/
insert into paso (descripcion) values ("%personaje% está en el inicio del Bosque Maldito, Donde se encuentra 3 caminos ... ¿por donde irá?");

/*Primera opcion*/

insert into opciones (descripcion) values ("Escoge el camino de la izquierda, a lo lejos se ve un puente colgante.,");
insert into respuesta (descripcion) values ("Decidido, piensas que es el camino más rapido, Para atravesar el bosque.");
insert into paso (descripcion) values ("Efectivamente, el puente es el cámino mas corto, no contabas con que el puente se descolgaría, Y no sobrevives a la caida. FIN");

/*Segunda opcion*/

insert into opciones (descripcion) values ("Escoge el camino del centro, del que parecen provenir, Ruidos de ramas al romperse y astillarse …");
insert into respuesta (descripcion) values ("Piensas que para ser digno de la espada de las valkirias, Debes de afrontar tus miedos y peligros que acechan");
insert into paso (descripcion) values ("Sorteando los peligros, llegas de noche al centro del bosque, y ves clavada en un cadaver una espada llameante que te susurra al oido... ¿Que haces?");

insert into opciones (descripcion) values ("Arrancas la espada de cuajo, ¡ERES %personaje%!',");
insert into respuesta (descripcion) values ("¡La espada es tuya, te invade la ira y la locura y vuelves Al poblado...");
insert into paso (descripcion) values ("Matas a toda tu gente, e invadido por la tristeza, decides arrancarte la vida. FIN");

insert into opciones (descripcion) values ("Atento a lo que dice la espada, escuchas levemente Las palabras ...matalos a todos ... por lo que decides No cogerla.");
insert into respuesta (descripcion) values ("¡La espada, al ver que eres un hombre fuerte y sensato, que eres capaz lo que dice, se entrega a ti como tu fiel Aliada.");
insert into paso (descripcion) values ("Mas fuerte que nunca, decides que es el momento de erradicar el mal junto A tu nueva aliada, y te embarcas en una nueva aventura. FIN.");


/*Tercera opcion*/

insert into opciones (descripcion) values ("Escoge el camino de la derecha, lleno de flores, ardillas …");
insert into respuesta (descripcion) values ("¿Que malo puede pasar?, parece salido de Disney. Con lo que no contabas es que en realidad has entrado al laberinto Sombrio, y al rato vuelves a la misma encruzijada");
/*Aqui en la tercera seria volver al paso principal opcion*/


