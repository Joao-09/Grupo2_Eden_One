
ALTER TABLE usuario modify id_usuario INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table usuario modify username varchar(30) NOT NULL UNIQUE;
Alter table usuario modify password varchar(30) NOT NULL;
Alter table usuario modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table usuario modify usuariocreacion varchar(30) NOT NULL ;
Alter table usuario modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table usuario modify usuariomodificacion varchar(30) NULL;

ALTER TABLE partida modify id_partida INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table partida modify name varchar(30) NOT NULL;
Alter table partida modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table partida modify usuariocreacion varchar(30) NOT NULL;
Alter table partida modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table partida modify usuariomodificacion varchar(30) NULL;


ALTER TABLE aventura modify id_aventura INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table aventura modify name varchar(30) NOT NULL;
Alter table aventura modify descripcion varchar(1000) NOT NULL;
Alter table aventura modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table aventura modify usuariocreacion varchar(30) NOT NULL;
Alter table aventura modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table aventura modify usuariomodificacion varchar(30) NULL;


ALTER TABLE personajes modify id_personajes INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table personajes modify name varchar(30) NOT NULL UNIQUE;
Alter table personajes modify descripcion varchar(300) NOT NULL;
Alter table personajes modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table personajes modify usuariocreacion varchar(30) NOT NULL;
Alter table personajes modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table personajes modify usuariomodificacion varchar(30) NULL;


ALTER TABLE paso modify id_paso INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table paso modify descripcion varchar(1000) NOT NULL;
Alter table paso modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table paso modify usuariocreacion varchar(30) NOT NULL;
Alter table paso modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table paso modify usuariomodificacion varchar(30) NULL;


ALTER TABLE respuesta modify id_respuesta INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table respuesta modify descripcion varchar(1000) NOT NULL;
Alter table respuesta modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table respuesta modify usuariocreacion varchar(30) NOT NULL;
Alter table respuesta modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table respuesta modify usuariomodificacion varchar(30) NULL;


ALTER TABLE opciones modify id_opciones INT UNSIGNED AUTO_INCREMENT PRIMARY KEY;
Alter table opciones modify descripcion varchar(1000);
Alter table opciones modify fechacreacion datetime NULL DEFAULT current_timestamp;
#Alter table opciones modify usuariocreacion varchar(30) NOT NULL;
Alter table opciones modify fechamodificacion timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
#Alter table opciones modify usuariomodificacion varchar(30) NULL;





