drop database if exists EDEN_ONE;

CREATE DATABASE if not exists EDEN_ONE;

use EDEN_ONE;

create table if not exists usuario (
id_usuario INT,
username varchar(30),
password varchar(30),
fechacreacion datetime ,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30) 
);

create table if not exists partida (
id_partida INT,
name varchar(30),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);

create table if not exists aventura (
id_aventura INT,
name varchar(30),
descripcion varchar(1000),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);

create table if not exists personajes (
id_personajes INT,
name varchar(30),
descripcion varchar(300),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);

create table if not exists paso (
id_paso INT,
descripcion varchar(1000),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);


create table if not exists respuesta (
id_respuesta INT,
descripcion varchar(1000),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);

create table if not exists opciones (
id_opciones INT,
descripcion varchar(1000),
fechacreacion datetime,
#usuariocreacion varchar(30),
fechamodificacion timestamp
#usuariomodificacion varchar(30)
);
